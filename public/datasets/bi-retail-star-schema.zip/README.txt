TensorMind - Retail Star Schema Dataset (2024-2025)
====================================================

Tables
------
Fact_Sales.csv     318 rows
  OrderID, OrderDate, CustomerID, ProductID, Quantity, UnitPrice, Discount, Revenue

Dim_Customers.csv  20 rows
  CustomerID, CustomerName, Segment, Country, City, SignupDate

Dim_Products.csv   10 rows
  ProductID, ProductName, Category, Subcategory, UnitCost, ListPrice

Dim_Date.csv       731 rows
  Date, Year, Quarter, MonthNumber, MonthName, YearMonth, DayOfWeek, IsWeekend

Expected control totals
-----------------------
Total Revenue (2024 + 2025): $135704.55
Revenue 2024: $61990.05
Revenue 2025: $73714.50
YoY 2025 vs 2024: +18.91%

Model
-----
Dim_Customers[CustomerID] 1 -> * Fact_Sales[CustomerID]
Dim_Products[ProductID]   1 -> * Fact_Sales[ProductID]
Dim_Date[Date]            1 -> * Fact_Sales[OrderDate]
Use single-direction relationships and mark Dim_Date as the date table.
